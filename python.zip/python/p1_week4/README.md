Symbol tables -
https://algs4.cs.princeton.edu/31elementary/

Binary search trees -
https://algs4.cs.princeton.edu/32bst/

Programming assignment - 8 puzzle problem -
https://coursera.cs.princeton.edu/algs4/assignments/8puzzle/specification.php
