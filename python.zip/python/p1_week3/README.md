Sorting info - 
https://algs4.cs.princeton.edu/20sorting/

Merge sort vs Quick sort
https://www.cs.wcupa.edu/rkline/ds/fast-sorts.html

Programming assignment - Collinear points
https://coursera.cs.princeton.edu/algs4/assignments/collinear/specification.php
