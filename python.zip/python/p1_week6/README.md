HASH TABLES and Week 6 -
https://algs4.cs.princeton.edu/34hash/
