Stack and queues - 
https://algs4.cs.princeton.edu/13stacks/

Elementry Sorting algo info - 
https://algs4.cs.princeton.edu/21elementary/

Programming assignment - Randomized queue and DEQUEUE
https://coursera.cs.princeton.edu/algs4/assignments/queues/specification.php
