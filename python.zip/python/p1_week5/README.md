Balance search tree(red-black)-
https://algs4.cs.princeton.edu/33balanced/

Programming assignment - KD tree problem -
https://coursera.cs.princeton.edu/algs4/assignments/kdtree/specification.php
