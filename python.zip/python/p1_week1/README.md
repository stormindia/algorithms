| Algorithm          | Worst case    |
| ------------- | ------------- |
| quick find  | M*N  |
| quick union  | M*N  |
| weighted quick union  | N + Mlog N  |
| QU + path compression  | N + Mlog N  |
| weighted QU + path compression  | N + Mlog*N  |

M union-find operations on a set on N elements

Union Find Info - https://algs4.cs.princeton.edu/15uf/

Programming assignment - Percolation problem
https://coursera.cs.princeton.edu/algs4/assignments/percolation/specification.php
