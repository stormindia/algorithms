Undirected GRAPHS - 
https://algs4.cs.princeton.edu/41graph/

Directed GRAPHS -
https://algs4.cs.princeton.edu/42digraph/

Programming assignment -
https://coursera.cs.princeton.edu/algs4/assignments/wordnet/specification.php
